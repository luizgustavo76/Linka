from .linkaFederations import LinkaFederations
otpauth://totp/PyPI:luizsgustavo76?secret=ec02b0e0ea643b76&issuer=PyPI